
const baseUrl = 'http://172.20.244.74'

export default baseUrl