

const baseUrl = 'http://180.101.225.214:88'
// 180.101.225.214:88

export default baseUrl